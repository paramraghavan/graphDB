"""Terminal API handlers."""
from jupyter_server_terminals.api_handlers import (
    TerminalAPIHandler,
    TerminalHandler,
    TerminalRootHandler,
)
